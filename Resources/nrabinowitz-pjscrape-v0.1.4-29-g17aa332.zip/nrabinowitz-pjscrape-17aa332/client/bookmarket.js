javascript:(function(d,s){s=d.createElement('script');s.src='https://github.com/nrabinowitz/pjscrape/raw/master/client/dev_harness.js';d.body.appendChild(s);})(document);
