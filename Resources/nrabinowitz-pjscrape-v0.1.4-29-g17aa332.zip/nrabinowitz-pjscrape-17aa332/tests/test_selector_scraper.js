pjs.addSuite({
    url: 'http://localhost:8888/test_site/index.html',
    scrapers: [
        'h1',
        'li a'
    ]
});