var myVar = "test1";
_pjs.myVar = "test2";