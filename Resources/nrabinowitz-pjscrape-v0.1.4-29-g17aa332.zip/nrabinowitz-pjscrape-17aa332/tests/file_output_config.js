// configuration for file-writing tests
pjs.config({
    writer: 'file',
    outFile: 'C:\\Temp\\pjscrape_out.txt'
});